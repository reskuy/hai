<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{

    public function login(Request $req){
        $user = User::where('username',$req->username)->where('password',$req->password)->with('department')->first();
        if($user != null){
            return $user;
        }else{
            return 'error';
        }
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return User::with('department')->get();
    }
    public function time(){

        date_default_timezone_set('Asia/Makassar');
        return date("l, j F Y h:i:s");
    }

    public function count(){
        return DB::table('user')->count();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $u = new User;
        $u->username = $request->Username;
        $u->password = $request->Password;
        $u->level = $request->Level;
        $u->nama_lengkap = $request->NamaLengkap;
        $u->id_department = $request->Department;
        $u->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return User::where('id_user',$id)->first();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $u = User::where('id_user',$id)
            ->update([
                'Username'=>$request->Username,
                'password'=>$request->Password,
                'nama_lengkap'=>$request->NamaLengkap,
                'id_department'=>$request->Department,
                'level'=>$request->Level]);
        return $u;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return DB::table('user')->where('id_user',$id)->delete();
    }
}
